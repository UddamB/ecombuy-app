from roundrobin.basic_rr import basic
from roundrobin.smooth_rr import smooth
from roundrobin.weighted_rr import weighted

__ALL__ = [basic, weighted, smooth]
