DEFAULT_EXTENSIONS = ['.py']
ALL_EXTENSIONS = object()


# Exit codes from pytest
# http://pytest.org/latest/_modules/_pytest/main.html
EXIT_OK = 0
EXIT_INTERRUPTED = 2
EXIT_NOTESTSCOLLECTED = 5
