Authors
=======

[Pytest-watch][home] is written and maintained by Joe Esposito,
along with the following contributors:

- Carsten Kraus ([@casio](https://github.com/casio))
- Rakjin Hwang ([@rakjin](https://github.com/rakjin))
- Carson Gee ([@carsongee](https://github.com/carsongee))
- Ivan Smirnov ([@aldanor](https://github.com/aldanor))
- Daniel Hahler ([@blueyed](https://github.com/blueyed))
- Colton J. Provias ([@ColtonProvias](https://github.com/ColtonProvias))
- Abhas Bhattacharya ([@bendtherules](https://github.com/bendtherules))
- Lukasz Balcerzak ([@lukaszb](https://github.com/lukaszb))
- Remco Haszing ([@remcohaszing](https://github.com/remcohaszing))
- Stefan Reichoer ([@xsteve](https://github.com/xsteve))
- Jace Browning ([@jacebrowning](https://github.com/jacebrowning))
- Emmanuel Leblond ([@touilleMan](https://github.com/touilleMan))
- Alex Ford ([@asford](https://github.com/asford))
- And Past ([@apast](https://github.com/apast))

[home]: README.md
