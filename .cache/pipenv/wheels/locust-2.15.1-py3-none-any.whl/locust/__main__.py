from .main import main

main()
